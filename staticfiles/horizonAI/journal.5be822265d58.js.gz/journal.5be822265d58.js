function createNewEntry() {
    const link = document.querySelector('.new-journal-link');
    
    link.addEventListener({
        
    })
}